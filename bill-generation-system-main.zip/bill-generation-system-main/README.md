# Bill Generation System

A professional bill generation system built with Flask, HTML, CSS, and JavaScript. Create, manage, and export invoices as PDF files.

## Features

✅ **Create Bills** - Generate professional invoices with company and customer details
✅ **Add Items** - Dynamically add multiple items to bills
✅ **Auto Calculations** - Automatic calculation of subtotal, tax, and total
✅ **View Bills** - View all bills in a list with filtering options
✅ **PDF Export** - Export bills as professional PDF documents
✅ **Delete Bills** - Remove bills from the system
✅ **Beautiful UI** - Responsive design with gradient theme
✅ **Real-time Preview** - Live preview of bills before saving
✅ **Alert Notifications** - User-friendly alert messages

## Project Structure

```
bill-generation-system/
├── app.py                 # Flask backend application
├── templates/
│   └── index.html        # Frontend (HTML + CSS + JS in one file)
├── requirements.txt      # Python dependencies
└── README.md            # Documentation
```

## Installation

### Prerequisites
- Python 3.7 or higher
- pip (Python package manager)

### Setup Steps

1. **Clone the repository**
   ```bash
   git clone https://github.com/anushkashinde309/bill-generation-system.git
   cd bill-generation-system
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   python app.py
   ```

5. **Open in browser**
   Navigate to `http://localhost:5000`

## Usage

### Creating a Bill
1. Fill in your company details (Bill From section)
2. Enter customer information (Bill To section)
3. Set the due date and tax rate
4. Add items to the bill by entering:
   - Item name
   - Description (optional)
   - Quantity
   - Price
5. Click "Generate Bill" to create the invoice

### Managing Bills
- **View** - Click the eye icon to see bill details
- **Export as PDF** - Click the PDF icon to download the bill
- **Delete** - Click the trash icon to remove the bill
- **Refresh** - Click Refresh List to update the bills list

## API Endpoints

### Generate Bill
- **POST** `/api/generate-bill`
- Create a new bill with the provided data

### Get All Bills
- **GET** `/api/bills`
- Retrieve all bills in the system

### Get Single Bill
- **GET** `/api/bill/<bill_id>`
- Retrieve a specific bill by ID

### Delete Bill
- **DELETE** `/api/bill/<bill_id>`
- Delete a bill by ID

### Export PDF
- **GET** `/api/bill/<bill_id>/pdf`
- Export a bill as PDF

## Technologies Used

- **Backend:** Flask (Python web framework)
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **PDF Generation:** ReportLab
- **Storage:** In-memory (easily replaceable with a database)

## File Details

### app.py
- Flask application setup
- API route handlers
- Bill generation and calculation logic
- PDF export functionality

### templates/index.html
- Complete frontend in a single HTML file
- HTML structure for the form and bill list
- CSS styling with responsive design
- JavaScript for interactivity and API calls

## Future Enhancements

- Database integration (SQLite, PostgreSQL)
- User authentication and authorization
- Email integration to send bills
- Bill templates and customization
- Payment tracking
- Recurring bills
- Multi-currency support
- Dark mode theme

## License

This project is open source and available under the MIT License.

## Support

For issues or questions, please create an issue on the GitHub repository.

## Author

Created by Anushka Shinde (@anushkashinde309)
